const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "df8icafxq",
  api_key: "218628971993324",
  api_secret: "PX2IKSROu2jg8nt-pwYaynzXVOw",
});

module.exports = cloudinary;